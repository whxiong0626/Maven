CREATE VIEW v_apply AS
  SELECT
    `g_c`.`g_idcard` AS `身份证号`,
    `g_a`.`g_state`  AS `表1申请状态`,
    `g_c`.`g_state`  AS `表2申请状态`
  FROM `myschool`.`g_cardapply` `g_a`
    JOIN `myschool`.`g_cardapplydetail` `g_c`
  WHERE ((`g_a`.`g_applyno` = `g_c`.`g_applyno`) AND (`g_c`.`g_idcard` = 440401430103082));
